# 2017-TSINGHUA-MEM-Group7
清华大学2017级MEM第二梯次入学导引课第七小组
请将资料上传至此
